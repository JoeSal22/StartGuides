﻿// See https://aka.ms/new-console-template for more information

using System.IO;
using System.Net.Http.Headers;
using System.Text;

string strUserDataFile = @".\UserSecurity.txt";
string strUserSecurityQuestions = @".\UserSecurityQuestions.txt";
string strTargetUser;

string[] strQuestions = new string[11];
string[] strUserData = new string[100];

int iUsers = 0;
int iQuestions = 0;

int ReadSecurityQuestionsFile()
{
    if (!File.Exists(strUserSecurityQuestions))
    {
        Console.WriteLine("Cannot continue - internal error:  security question file does not exist!");
        return -1;
    }
    else
    {
        int iQuestions = 0;
        using (StreamReader srQuestions = File.OpenText(strUserSecurityQuestions))
        {
            string strTemp;
            while ((strTemp = srQuestions.ReadLine()) != null)
            {
                strQuestions[iQuestions] = strTemp;
                //Console.WriteLine(strQuestions[iCount]);
                iQuestions++;
            }
        }
        return iQuestions;
    }
}

int ReadUserData() 
{
    int iCount = 0;

    if (File.Exists(strUserDataFile))
    {
        using (StreamReader sr = File.OpenText(strUserDataFile))
        {
            string strTemp;
            while ((strTemp = sr.ReadLine()) != null)
            {
                strUserData[iCount] = strTemp;
               // Console.WriteLine(strUserData[iCount]);
                iCount++;
            }
            sr.Close();
        }
    }
    else
    {
        using (FileStream fs = File.Create(strUserDataFile)) ;
    }
    return iCount;
}

Boolean bIsUserFound(string strTempUser)
{
    //Console.WriteLine("looking for: " + strTempUser);
    for (int i = 0; i < iUsers; i++)
    {
        //Console.WriteLine(strUserData[i]);
        if (strUserData[i].StartsWith(strTempUser, StringComparison.OrdinalIgnoreCase))
        {
            //Console.WriteLine("matched:" + strTempUser);
            return true;
        }
    }
    //Console.WriteLine("could not match:" + strTempUser);
    return false;
}

void AnswerQuestions()
{
    string strQuestion1;
    string strQuestion2;
    string strQuestion3;

    Boolean bUserFound = false;
    // find the user
    for (int i = 0; i < iUsers; i++)
    {
        if (strUserData[i].StartsWith(strTargetUser, StringComparison.OrdinalIgnoreCase))
        {
            //Console.WriteLine("matched:" + strUserData[i]);
            bUserFound = true;
            string[] questions = strUserData[i].Split(',');

            strQuestion1 = questions[1];
            string[] QA1 = strQuestion1.Split("?");
            string strQ1 = QA1[0];
            string strA1 = QA1[1];

            strQuestion2 = questions[2];
            string[] QA2 = strQuestion2.Split("?");
            string strQ2 = QA2[0];
            string strA2 = QA2[1];

            strQuestion3 = questions[3];
            string[] QA3 = strQuestion3.Split("?");
            string strQ3 = QA3[0];
            string strA3 = QA3[1];

            // Console.WriteLine("Q1=" + strQ1 + " A1=" + strA1);
            //Console.WriteLine("Q2=" + strQ2 + " A2=" + strA2);
            // Console.WriteLine("Q3=" + strQ3 + " A3=" + strA3);

            Boolean bAnswered = false;

            for (int j = 0; j < 3; j++)
            {
                if (bAnswered == true)
                {
                    break;
                }
                string strResponse;
                switch (j)
                {
                    case 0:
                        Console.WriteLine(strQ1 + "?");
                        strResponse = Console.ReadLine();
                        if (strResponse.ToLower() == strA1.ToLower())
                        {
                            Console.WriteLine("Congratulations, your successfully answered your security question!  Have a nice day.");
                            bAnswered = true;
                        }
                        break;
                    case 1:
                        Console.WriteLine(strQ2 + "?");
                        strResponse = Console.ReadLine();
                        if (strResponse.ToLower() == strA2.ToLower())
                        {
                            Console.WriteLine("Congratulations, your successfully answered your security question!  Have a nice day.");
                            bAnswered = true;
                        }
                        break;
                    case 2:
                        Console.WriteLine(strQ3 + "?");
                        strResponse = Console.ReadLine();
                        if (strResponse.ToLower() == strA3.ToLower())
                        {
                            Console.WriteLine("Congratulations, your successfully answered your security question!  Have a nice day.");
                            bAnswered = true;
                        }
                        break;
                }
            }

            if (!bAnswered)
            {
                Console.WriteLine("I'm sorry, you have run our of security questions.  Please try again.");
            }
            break;
        }
    }
}

void AddUser(string strNewUser)
{
    //Console.WriteLine("AddUser: " + strNewUser);
    using (StreamWriter w = File.AppendText(strUserDataFile))
    {
        strNewUser = strNewUser + "\n";
        w.Write(strNewUser );
    }
    return;
}
string AskQuestions()
{
    int iAnswered = 0;
    string strAnswers = null;
    while (iAnswered < 3)
    {
        string strResponse;

        for (int iCount = 0; iCount < iQuestions && iAnswered != 3; iCount++)
        {
            Console.WriteLine(strQuestions[iCount]);
            strResponse = Console.ReadLine();
            //Console.WriteLine("here" + strResponse.Length);
            if (strResponse != null && strResponse.Length > 0)
            {
                iAnswered++;
                if (iAnswered == 3)
                {
                    strAnswers += strQuestions[iCount] + strResponse;
                }
                else {

                strAnswers += strQuestions[iCount] + strResponse + ",";
                }
                //Console.WriteLine(strAnswers);
            }
        }
    }
    return strAnswers;
}

try
{
    string strResponse;

    iQuestions = ReadSecurityQuestionsFile();
    if (iQuestions == -1)
    {
        return -1;
    }

    while (true)
    {
        iUsers = ReadUserData();
        Console.WriteLine("Hello, what is your name?");

        strTargetUser = Console.ReadLine();

        if (bIsUserFound(strTargetUser))
        {
            AnswerQuestions();
        } 
        else
        {
            Console.WriteLine("Would you like to store answers to security questions (y/n)? ");
            strResponse = Console.ReadLine();

            if (strResponse.ToLower() == "y")
            {
                string strNewUser = strTargetUser + "," + AskQuestions();
                //Console.WriteLine(strNewUser);
                AddUser(strNewUser);
            }
        }
    }
}
catch (Exception ex)
{
    Console.WriteLine(ex.ToString());
}

return 0;
